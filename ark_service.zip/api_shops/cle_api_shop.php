<?php 
//----Lien des images de produits 
$image_produit = "https://akila.store/_ressources/images_articles/";
//-----
$id_website= '5062126872';
// $id_website= '7220708820';

include "api_shops/api_produit.php";
include "api_shops/api_boutique.php";
include "api_shops/api_cat_produit.php";
include "api_shops/fonctions.php";
include "api/fonctions.php";
